A "Save the date"/ "RSVP" / "Wedding invite" designed by me.

Just replace the photos and timer and you are ready to go. I'd love to help you with it.

Some samples uploaded on a free hosting service

Some usages (will expire soon)

http://saurabhwedshimani.com/
http://nitikawedsrahul.com/

Feel free to extend it for your own use.


Thanks
Alan
